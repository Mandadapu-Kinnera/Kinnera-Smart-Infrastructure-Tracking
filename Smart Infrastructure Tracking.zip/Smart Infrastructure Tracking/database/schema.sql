mysql -u root -p
USE flaskdb;
SELECT * FROM users;
